package wall;

public class Wall {

}
